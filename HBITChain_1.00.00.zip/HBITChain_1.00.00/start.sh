#!/bin/sh
APPLICATION="HBITChain"
if [ -e ~/.${APPLICATION}/hbit.pid ]; then
    PID=$(cat ~/.${APPLICATION}/hbit.pid)
    ps -p "$PID" > /dev/null
    STATUS=$?
    if [ $STATUS -eq 0 ]; then
        echo "HBIT server already running"
        exit 1
    fi
fi
mkdir -p ~/.${APPLICATION}/
DIR=$(dirname "$0")
cd "${DIR}" || exit
if [ -x jre/bin/java ]; then
    JAVA=./jre/bin/java
else
    JAVA=java
fi
nohup ${JAVA} -cp classes:lib/*:conf:addons/classes:addons/lib/* -Dhbit.runtime.mode=desktop hbit.Hbit > /dev/null 2>&1 &
echo $! > ~/.${APPLICATION}/hbit.pid
cd - > /dev/null || exit